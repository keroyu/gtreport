<?php
	phpinfo()
?>